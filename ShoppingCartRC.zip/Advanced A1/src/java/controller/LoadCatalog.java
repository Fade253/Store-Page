package controller;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import entity.Monitor;
import entity.Order;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rfcla
 */
@WebServlet(name="LoadCatalog", urlPatterns = {"/LoadCatalog"})
public class LoadCatalog extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String fileName = "/monitors.csv";
        
        if(request.getSession().getAttribute("orders")!=null)
        {
            RequestDispatcher rd = request.getRequestDispatcher("/showMonitors.jsp");
            rd.forward(request, response);
        }
        else{
        List<Order> Orders = new ArrayList();
        ServletContext context = getServletContext();
        InputStream stream = context.getResourceAsStream(fileName);
        if (stream == null) {
            request.setAttribute("error", "file name not found");
            request.getRequestDispatcher("/errorPage.jsp").forward(request, response);  
        }
        
        Scanner sc = new Scanner(stream);
        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            String[] pieces = line.split(",");
            boolean ips = false;
            int partNum = Integer.parseInt(pieces[0]);
            String description = pieces[1];
            String resolution = pieces[2];
            double size = Double.parseDouble(pieces[3]);
            String refreshRate = pieces[4];

            if (pieces[5].equals("Yes"))
            {
            ips = true;
            }
            else if (pieces[5].equals("No"))
            {
            ips = false;
            }
            
            double price = Double.parseDouble(pieces[6]);
            Monitor monitor = new Monitor(partNum, description,resolution, size, refreshRate, ips, price);
            Orders.add(new Order(monitor, 0));
        }
System.out.println(request);
        request.getSession().setAttribute("orders", Orders);
        request.setAttribute("orders", Orders);
        
      RequestDispatcher rd = request.getRequestDispatcher("/showMonitors.jsp");
     rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
